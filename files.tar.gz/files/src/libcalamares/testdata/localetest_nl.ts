<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: no
     SPDX-License-Identifier: CC0-1.0
-->
<!DOCTYPE TS>
<TS language="nl" version="2.1">
  <context>
    <name>LocaleTests</name>
    <message>
      <location filename="Tests.cpp" line="22"/>
      <source>Quit</source>
      <translation>Ophouden</translation>
    </message>
  </context>
</TS>
